// import { defineConfig } from 'vite';
// import react from '@vitejs/plugin-react';

// export default defineConfig({
//   plugins: [react()],
//   server: {
//     proxy: {
//       '/api': {
//         target: 'http://210.212.210.81:3000/', // Backend API
//         changeOrigin: true,
//         rewrite: (path) => path.replace(/^\/api/, ''), 
//       },
//     },
//   },
// });
